
<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-eye-fill me-1"></i>Détail</span>
    <h1 class="page-title mb-0">Détail du technicien</h1>
</div>

<div class="content-card p-4 mb-4">
    <div class="card-body">
        <p><strong>Nom :</strong> <?php echo e($technicien->nom); ?></p>
        <p><strong>Prénom :</strong> <?php echo e($technicien->prenom); ?></p>
        <p><strong>Spécialité :</strong> <?php echo e($technicien->specialite); ?></p>
    </div>
</div>

<h3>Réparations associées</h3>
<div class="table-responsive content-card p-3">
    <table class="table align-middle table-hover mb-0">
        <thead>
            <tr>
                <th>Date</th>
                <th>Objet</th>
                <th>Véhicule</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $technicien->reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($reparation->date); ?></td>
                <td><?php echo e($reparation->objet_reparation); ?></td>
                <td><?php echo e($reparation->vehicule?->immatriculation); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center text-muted">Aucune réparation associée.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/techniciens/show.blade.php ENDPATH**/ ?>
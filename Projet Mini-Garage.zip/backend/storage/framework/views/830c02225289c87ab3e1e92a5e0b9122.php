<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestion de Garage</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        :root {
            --garage-ink: #102033;
            --garage-accent: #f97316;
            --garage-accent-2: #0ea5e9;
            --garage-surface: rgba(255, 255, 255, 0.92);
        }

        body {
            font-family: 'Inter', sans-serif;
            background:
                radial-gradient(circle at top left, rgba(14, 165, 233, 0.14), transparent 28%),
                radial-gradient(circle at top right, rgba(249, 115, 22, 0.14), transparent 26%),
                linear-gradient(180deg, #f8fafc 0%, #eef4fb 100%);
            color: var(--garage-ink);
            min-height: 100vh;
        }

        .garage-shell {
            backdrop-filter: blur(12px);
            background: var(--garage-surface);
            border: 1px solid rgba(16, 32, 51, 0.08);
            box-shadow: 0 24px 80px rgba(16, 32, 51, 0.08);
            border-radius: 1.5rem;
        }

        .garage-navbar {
            background: linear-gradient(135deg, #102033 0%, #1f3b57 100%);
            box-shadow: 0 16px 50px rgba(16, 32, 51, 0.28);
        }

        .garage-brand {
            letter-spacing: 0.08em;
            text-transform: uppercase;
            font-weight: 800;
        }

        .garage-hero-badge {
            background: rgba(14, 165, 233, 0.12);
            color: #075985;
        }

        .page-title {
            font-size: clamp(1.7rem, 2vw, 2.3rem);
            font-weight: 800;
            margin-bottom: 0.25rem;
        }

        .page-lead {
            color: #5b6877;
        }

        .nav-pills .nav-link {
            color: rgba(255, 255, 255, 0.86);
            border-radius: 999px;
            padding-inline: 1rem;
        }

        .nav-pills .nav-link.active,
        .nav-pills .show>.nav-link {
            background: rgba(255, 255, 255, 0.16);
            color: #fff;
        }

        .btn-garage {
            background: linear-gradient(135deg, var(--garage-accent) 0%, #ea580c 100%);
            border: none;
            color: #fff;
            box-shadow: 0 12px 24px rgba(249, 115, 22, 0.22);
        }

        .btn-garage:hover {
            color: #fff;
            transform: translateY(-1px);
        }

        .content-card {
            background: rgba(255, 255, 255, 0.78);
            border: 1px solid rgba(16, 32, 51, 0.08);
            border-radius: 1.25rem;
            box-shadow: 0 16px 40px rgba(15, 23, 42, 0.08);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark garage-navbar py-3">
        <div class="container">
            <a class="navbar-brand garage-brand d-flex align-items-center gap-2" href="<?php echo e(url('/')); ?>">
                <span class="bg-white text-dark rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 2rem; height: 2rem;">
                    <i class="bi bi-tools"></i>
                </span>
                Mini Garage
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#garageNav" aria-controls="garageNav" aria-expanded="false" aria-label="Basculer la navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="garageNav">
                <ul class="navbar-nav ms-auto nav-pills gap-2">
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('vehicules.*') ? 'active' : ''); ?>" href="<?php echo e(route('vehicules.index')); ?>"><i class="bi bi-car-front me-1"></i>Véhicules</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('reparations.*') ? 'active' : ''); ?>" href="<?php echo e(route('reparations.index')); ?>"><i class="bi bi-wrench-adjustable-circle me-1"></i>Réparations</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('techniciens.*') ? 'active' : ''); ?>" href="<?php echo e(route('techniciens.index')); ?>"><i class="bi bi-people me-1"></i>Techniciens</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container py-4 py-lg-5">
        <div class="garage-shell p-3 p-lg-4">
            <?php if(session('success')): ?>
            <div class="alert alert-success d-flex align-items-center gap-2" role="alert">
                <i class="bi bi-check-circle-fill"></i>
                <div><?php echo e(session('success')); ?></div>
            </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/layout.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<h2><?php echo e(isset($vehicule) ? 'Modifier' : 'Ajouter'); ?> un véhicule</h2>
<form method="POST" action="<?php echo e(isset($vehicule) ? route('vehicules.update', $vehicule) : route('vehicules.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($vehicule)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <?php $__currentLoopData = ['immatriculation','marque','modele','couleur','annee','kilometrage','carrosserie','energie','boite']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mb-2">
        <label><?php echo e(ucfirst($field)); ?></label>
        <input type="<?php echo e(in_array($field,['annee','kilometrage']) ? 'number':'text'); ?>"
            name="<?php echo e($field); ?>" class="form-control"
            value="<?php echo e(old($field, $vehicule->$field ?? '')); ?>" required>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button class="btn btn-success mt-2">Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/vehicules/edit.blade.php ENDPATH**/ ?>
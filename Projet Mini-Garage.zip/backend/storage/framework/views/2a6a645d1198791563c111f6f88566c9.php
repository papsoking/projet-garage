
<?php $__env->startSection('content'); ?>
<h2><?php echo e(isset($technicien) ? 'Modifier' : 'Ajouter'); ?> un technicien</h2>
<form method="POST" action="<?php echo e(isset($technicien) ? route('techniciens.update', $technicien) : route('techniciens.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($technicien)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="mb-2">
        <label>Nom</label>
        <input type="text" name="nom" class="form-control" value="<?php echo e(old('nom', $technicien->nom ?? '')); ?>" required>
    </div>
    <div class="mb-2">
        <label>Prénom</label>
        <input type="text" name="prenom" class="form-control" value="<?php echo e(old('prenom', $technicien->prenom ?? '')); ?>" required>
    </div>
    <div class="mb-2">
        <label>Spécialité</label>
        <input type="text" name="specialite" class="form-control" value="<?php echo e(old('specialite', $technicien->specialite ?? '')); ?>" required>
    </div>
    <button class="btn btn-success mt-2">Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/techniciens/edit.blade.php ENDPATH**/ ?>
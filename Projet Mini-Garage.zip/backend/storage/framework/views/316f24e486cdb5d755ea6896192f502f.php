
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-end gap-3 mb-4">
    <div>
        <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-car-front-fill me-1"></i>Catalogue</span>
        <h1 class="page-title mb-0">Liste des véhicules</h1>
        <p class="page-lead mb-0">Consultez, recherchez et gérez le parc automobile du garage.</p>
    </div>
    <a href="<?php echo e(route('vehicules.create')); ?>" class="btn btn-garage px-4">
        <i class="bi bi-plus-circle me-2"></i>Ajouter un véhicule
    </a>
</div>

<!-- Formulaire de recherche -->
<form class="row g-2 mb-4" method="GET" action="<?php echo e(route('vehicules.index')); ?>">
    <div class="col-lg-8">
        <div class="input-group">
            <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
            <input type="text" name="search" class="form-control" placeholder="Rechercher par marque ou immatriculation" value="<?php echo e(request('search')); ?>">
        </div>
    </div>
    <div class="col-lg-4 d-flex gap-2">
        <button class="btn btn-outline-primary flex-fill" type="submit"><i class="bi bi-funnel me-1"></i>Filtrer</button>
        <a href="<?php echo e(route('vehicules.index')); ?>" class="btn btn-outline-secondary flex-fill">Réinitialiser</a>
    </div>
</form>

<!-- Boutons de vue -->
<div class="mb-3 d-flex gap-2">
    <a href="<?php echo e(route('vehicules.index', ['view' => 'table', 'search' => request('search')])); ?>"
       class="btn <?php echo e(request('view', 'table') == 'table' ? 'btn-primary' : 'btn-outline-primary'); ?>">
        <i class="bi bi-table"></i> Tableau
    </a>

    <a href="<?php echo e(route('vehicules.index', ['view' => 'card', 'search' => request('search')])); ?>"
       class="btn <?php echo e(request('view') == 'card' ? 'btn-primary' : 'btn-outline-primary'); ?>">
        <i class="bi bi-grid-3x3-gap"></i> Cartes
    </a>
</div>

<!-- Contenu principal -->
<?php if(request('view', 'table') == 'table'): ?>

<div class="table-responsive content-card p-3">
    <table class="table align-middle table-hover mb-0">
        <thead>
            <tr>
                <th>Immatriculation</th>
                <th>Marque</th>
                <th>Modèle</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($v->immatriculation); ?></td>
                <td><?php echo e($v->marque); ?></td>
                <td><?php echo e($v->modele); ?></td>
                <td>
                    <a href="<?php echo e(route('vehicules.show', $v)); ?>"
                       class="btn btn-outline-info btn-sm">
                        <i class="bi bi-eye"></i> Voir
                    </a>

                    <a href="<?php echo e(route('vehicules.edit', $v)); ?>"
                       class="btn btn-outline-warning btn-sm">
                        <i class="bi bi-pencil-square"></i> Modifier
                    </a>

                    <form action="<?php echo e(route('vehicules.destroy', $v)); ?>"
                          method="POST"
                          class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button class="btn btn-outline-danger btn-sm"
                            onclick="return confirm('Supprimer ce véhicule ?')">
                            <i class="bi bi-trash"></i> Supprimer
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php else: ?>

<div class="row">
    <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-4 mb-4">
            <?php if (isset($component)) { $__componentOriginalfccc8a24b82321d6a7601591b339f60a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfccc8a24b82321d6a7601591b339f60a = $attributes; } ?>
<?php $component = App\View\Components\VehiculeCard::resolve(['vehicule' => $vehicule] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('vehicule-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\VehiculeCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfccc8a24b82321d6a7601591b339f60a)): ?>
<?php $attributes = $__attributesOriginalfccc8a24b82321d6a7601591b339f60a; ?>
<?php unset($__attributesOriginalfccc8a24b82321d6a7601591b339f60a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfccc8a24b82321d6a7601591b339f60a)): ?>
<?php $component = $__componentOriginalfccc8a24b82321d6a7601591b339f60a; ?>
<?php unset($__componentOriginalfccc8a24b82321d6a7601591b339f60a); ?>
<?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/vehicules/index.blade.php ENDPATH**/ ?>
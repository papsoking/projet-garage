
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-end gap-3 mb-4">
    <div>
        <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-clipboard-check me-1"></i>Suivi atelier</span>
        <h1 class="page-title mb-0">Liste des réparations</h1>
        <p class="page-lead mb-0">Visualisez les interventions, le véhicule concerné et les techniciens affectés.</p>
    </div>
    <a href="<?php echo e(route('reparations.create')); ?>" class="btn btn-garage px-4">
        <i class="bi bi-plus-circle me-2"></i>Ajouter une réparation
    </a>
</div>

<div class="table-responsive content-card p-3">
    <table class="table align-middle table-hover mb-0">
        <thead>
            <tr>
                <th>Date</th>
                <th>Objet</th>
                <th>Véhicule</th>
                <th>Techniciens</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($r->date); ?></td>
                <td><?php echo e($r->objet_reparation); ?></td>
                <td><?php echo e($r->vehicule->immatriculation); ?></td>
                <td>
                    <?php $__currentLoopData = $r->techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge text-bg-info"><?php echo e($tech->prenom); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <a href="<?php echo e(route('reparations.show', $r)); ?>" class="btn btn-outline-info btn-sm"><i class="bi bi-eye me-1"></i>Voir</a>
                    <a href="<?php echo e(route('reparations.edit', $r)); ?>" class="btn btn-outline-warning btn-sm"><i class="bi bi-pencil-square me-1"></i>Modifier</a>
                    <form action="<?php echo e(route('reparations.destroy', $r)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Supprimer cette réparation ?')"><i class="bi bi-trash me-1"></i>Supprimer</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/reparations/index.blade.php ENDPATH**/ ?>
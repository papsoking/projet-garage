
<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-clipboard-plus me-1"></i>Intervention atelier</span>
    <h1 class="page-title mb-0"><?php echo e(isset($reparation) ? 'Modifier' : 'Ajouter'); ?> une réparation</h1>
    <p class="page-lead mb-0">Associez un véhicule et un ou plusieurs techniciens à l'intervention.</p>
</div>

<form method="POST" action="<?php echo e(isset($reparation) ? route('reparations.update', $reparation) : route('reparations.store')); ?>" class="content-card p-4">
    <?php echo csrf_field(); ?>
    <?php if(isset($reparation)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="mb-2">
        <label>Véhicule</label>
        <select name="vehicule_id" class="form-control" required>
            <?php $__currentLoopData = $vehicules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($v->id); ?>" <?php if(isset($reparation) && $reparation->vehicule_id == $v->id): echo 'selected'; endif; ?>>
                <?php echo e($v->immatriculation); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-2">
        <label>Date</label>
        <input type="date" name="date" class="form-control" value="<?php echo e(old('date', $reparation->date ?? '')); ?>" required>
    </div>
    <div class="mb-2">
        <label>Durée main d'œuvre</label>
        <input type="text" name="duree_main_oeuvre" class="form-control" value="<?php echo e(old('duree_main_oeuvre', $reparation->duree_main_oeuvre ?? '')); ?>" required>
    </div>
    <div class="mb-2">
        <label>Objet de la réparation</label>
        <textarea name="objet_reparation" class="form-control" required><?php echo e(old('objet_reparation', $reparation->objet_reparation ?? '')); ?></textarea>
    </div>
    <div class="mb-2">
        <label>Techniciens</label>
        <?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="techniciens[]" value="<?php echo e($t->id); ?>"
                <?php if(isset($selectedTechniciens) && in_array($t->id, $selectedTechniciens)): echo 'checked'; endif; ?>>
            <label class="form-check-label"><?php echo e($t->prenom); ?> <?php echo e($t->nom); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button class="btn btn-garage mt-2"><i class="bi bi-check2-circle me-1"></i>Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/reparations/create.blade.php ENDPATH**/ ?>
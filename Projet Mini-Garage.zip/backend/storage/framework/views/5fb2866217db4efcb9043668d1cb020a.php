
<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-eye-fill me-1"></i>Détail</span>
    <h1 class="page-title mb-0">Détail du véhicule</h1>
</div>

<div class="content-card p-4 mb-4">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Immatriculation</small><strong><?php echo e($vehicule->immatriculation); ?></strong></div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Marque</small><strong><?php echo e($vehicule->marque); ?></strong></div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Modèle</small><strong><?php echo e($vehicule->modele); ?></strong></div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Couleur</small><strong><?php echo e($vehicule->couleur); ?></strong></div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Année</small><strong><?php echo e($vehicule->annee); ?></strong></div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Kilométrage</small><strong><?php echo e($vehicule->kilometrage); ?></strong></div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Carrosserie</small><strong><?php echo e($vehicule->carrosserie); ?></strong></div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Énergie</small><strong><?php echo e($vehicule->energie); ?></strong></div>
            </div>
            <div class="col-md-4">
                <div class="p-3 rounded-3 bg-light"><small class="text-muted d-block">Boîte</small><strong><?php echo e($vehicule->boite); ?></strong></div>
            </div>
        </div>
    </div>
</div>

<h3>Réparations associées</h3>
<div class="table-responsive content-card p-3">
    <table class="table align-middle table-hover mb-0">
        <thead>
            <tr>
                <th>Date</th>
                <th>Objet</th>
                <th>Durée</th>
                <th>Techniciens</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $vehicule->reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($reparation->date); ?></td>
                <td><?php echo e($reparation->objet_reparation); ?></td>
                <td><?php echo e($reparation->duree_main_oeuvre); ?></td>
                <td>
                    <?php $__currentLoopData = $reparation->techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge text-bg-info"><?php echo e($technicien->prenom); ?> <?php echo e($technicien->nom); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-center text-muted">Aucune réparation associée.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/vehicules/show.blade.php ENDPATH**/ ?>
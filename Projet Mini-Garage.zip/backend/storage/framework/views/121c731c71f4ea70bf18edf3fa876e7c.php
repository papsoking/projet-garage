
<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-person-badge me-1"></i>Fiche technicien</span>
    <h1 class="page-title mb-0"><?php echo e(isset($technicien) ? 'Modifier' : 'Ajouter'); ?> un technicien</h1>
    <p class="page-lead mb-0">Complétez les informations de l'intervenant atelier.</p>
</div>

<form method="POST" action="<?php echo e(isset($technicien) ? route('techniciens.update', $technicien) : route('techniciens.store')); ?>" class="content-card p-4">
    <?php echo csrf_field(); ?>
    <?php if(isset($technicien)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="mb-2">
        <label>Nom</label>
        <input type="text" name="nom" class="form-control" value="<?php echo e(old('nom', $technicien->nom ?? '')); ?>" required>
    </div>
    <div class="mb-2">
        <label>Prénom</label>
        <input type="text" name="prenom" class="form-control" value="<?php echo e(old('prenom', $technicien->prenom ?? '')); ?>" required>
    </div>
    <div class="mb-2">
        <label>Spécialité</label>
        <input type="text" name="specialite" class="form-control" value="<?php echo e(old('specialite', $technicien->specialite ?? '')); ?>" required>
    </div>
    <button class="btn btn-garage mt-2"><i class="bi bi-check2-circle me-1"></i>Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/techniciens/create.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-car-front-fill me-1"></i>Fiche véhicule</span>
    <h1 class="page-title mb-0"><?php echo e(isset($vehicule) ? 'Modifier' : 'Ajouter'); ?> un véhicule</h1>
    <p class="page-lead mb-0">Renseignez les informations techniques et administratives du véhicule.</p>
</div>

<form method="POST" action="<?php echo e(isset($vehicule) ? route('vehicules.update', $vehicule) : route('vehicules.store')); ?>" class="content-card p-4">
    <?php echo csrf_field(); ?>
    <?php if(isset($vehicule)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <?php $__currentLoopData = ['immatriculation','marque','modele','couleur','annee','kilometrage','carrosserie','energie','boite']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mb-2">
        <label><?php echo e(ucfirst($field)); ?></label>
        <input type="<?php echo e(in_array($field,['annee','kilometrage']) ? 'number':'text'); ?>"
            name="<?php echo e($field); ?>" class="form-control <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old($field, isset($vehicule) ? $vehicule->$field : '')); ?>" required>
        <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button class="btn btn-garage mt-2"><i class="bi bi-check2-circle me-1"></i>Enregistrer</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 5\backend\resources\views/vehicules/create.blade.php ENDPATH**/ ?>
<div class="card shadow-sm h-100">
    <div class="card-body">
        <h5 class="card-title">
            <?php echo e($vehicule->immatriculation); ?>

        </h5>

        <p class="mb-1">
            <strong>Marque :</strong> <?php echo e($vehicule->marque); ?>

        </p>

        <p class="mb-1">
            <strong>Modèle :</strong> <?php echo e($vehicule->modele); ?>

        </p>

        <p class="mb-0">
            <strong>Couleur :</strong> <?php echo e($vehicule->couleur); ?>

        </p>

        <a href="<?php echo e(route('vehicules.show', $vehicule)); ?>"
           class="btn btn-primary btn-sm mt-3">
            <i class="bi bi-eye me-1"></i> Détails
        </a>

        <a href="<?php echo e(route('vehicules.edit', $vehicule)); ?>"
           class="btn btn-warning btn-sm mt-3">
            <i class="bi bi-pencil-square me-1"></i> Modifier
        </a>
        <form action="<?php echo e(route('vehicules.destroy', $vehicule)); ?>"
              method="POST"
              class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <button class="btn btn-danger btn-sm mt-3"
                onclick="return confirm('Supprimer ce véhicule ?')">
                <i class="bi bi-trash me-1"></i> Supprimer
            </button>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/components/vehicule-card.blade.php ENDPATH**/ ?>
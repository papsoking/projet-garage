
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-end gap-3 mb-4">
    <div>
        <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-people-fill me-1"></i>Équipe atelier</span>
        <h1 class="page-title mb-0">Liste des techniciens</h1>
        <p class="page-lead mb-0">Gérez les profils et les spécialités de l’équipe du garage.</p>
    </div>
    <a href="<?php echo e(route('techniciens.create')); ?>" class="btn btn-garage px-4">
        <i class="bi bi-plus-circle me-2"></i>Ajouter un technicien
    </a>
</div>

<div class="table-responsive content-card p-3">
    <table class="table align-middle table-hover mb-0">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Spécialité</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($t->nom); ?></td>
                <td><?php echo e($t->prenom); ?></td>
                <td><?php echo e($t->specialite); ?></td>
                <td>
                    <a href="<?php echo e(route('techniciens.show', $t)); ?>" class="btn btn-outline-info btn-sm"><i class="bi bi-eye me-1"></i>Voir</a>
                    <a href="<?php echo e(route('techniciens.edit', $t)); ?>" class="btn btn-outline-warning btn-sm"><i class="bi bi-pencil-square me-1"></i>Modifier</a>
                    <form action="<?php echo e(route('techniciens.destroy', $t)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-outline-danger btn-sm" onclick="return confirm('Supprimer ce technicien ?')"><i class="bi bi-trash me-1"></i>Supprimer</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 5\backend\resources\views/techniciens/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <span class="badge garage-hero-badge rounded-pill mb-2"><i class="bi bi-eye-fill me-1"></i>Détail</span>
    <h1 class="page-title mb-0">Détail de la réparation</h1>
</div>

<div class="content-card p-4 mb-4">
    <div class="card-body">
        <p><strong>Date :</strong> <?php echo e($reparation->date); ?></p>
        <p><strong>Objet :</strong> <?php echo e($reparation->objet_reparation); ?></p>
        <p><strong>Durée main d'œuvre :</strong> <?php echo e($reparation->duree_main_oeuvre); ?></p>
        <p><strong>Véhicule :</strong> <?php echo e($reparation->vehicule?->immatriculation); ?></p>
    </div>
</div>

<h3>Techniciens associés</h3>
<div class="content-card p-3 d-flex flex-wrap gap-2">
    <?php $__currentLoopData = $reparation->techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <span class="badge text-bg-info"><?php echo e($technicien->prenom); ?> <?php echo e($technicien->nom); ?></span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\D-CLIC\Avancée\Semaine 4\mini_garage\resources\views/reparations/show.blade.php ENDPATH**/ ?>